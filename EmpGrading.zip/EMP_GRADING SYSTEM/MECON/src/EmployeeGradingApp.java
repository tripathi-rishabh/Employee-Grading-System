import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EmployeeGradingApp {
    private JTextField empIdField;
    private JTextArea resultArea;
    private JButton searchButton;
    private JButton clearButton;
    private JFrame frame;

    public EmployeeGradingApp() {
        // Initialize components
        empIdField = new JTextField(10);
        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);
        searchButton = new JButton("Search");
        clearButton = new JButton("Clear");

        // Set up layout
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(new JLabel("Enter EmpID to know the grade:"));
        panel.add(empIdField);
        panel.add(searchButton);
        panel.add(clearButton);
        panel.add(new JScrollPane(resultArea));

        // Add action listeners
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchEmployeeGrade();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        // Set up frame
        frame = new JFrame("Employee Grading System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    private void searchEmployeeGrade() {
        String empId = empIdField.getText().trim();
        if (empId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter an Employee ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String url = "jdbc:mysql://localhost:3306/mecon";
        String username = "Rishabh";
        String password = "6163";

        try (java.sql.Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT EmpID, EmpName, Overall, Percentage " +
                             "FROM performance NATURAL JOIN attendance NATURAL JOIN employee " +
                             "WHERE EmpID = ?")) {

            stmt.setString(1, empId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String empName = rs.getString("EmpName");
                double percentageOfAttendance = rs.getDouble("Percentage");
                int overallPerformance = rs.getInt("Overall");
                String grade;

                if(overallPerformance>=40 && percentageOfAttendance>=90.0) {
                    grade = "A+";
                } else if (overallPerformance >= 35 && overallPerformance < 40 && percentageOfAttendance >= 80.0) {
                    grade = "A";
                } else if (overallPerformance >= 30 && overallPerformance < 35 && percentageOfAttendance >= 70.0) {
                    grade = "B";
                } else if (overallPerformance >= 25 && overallPerformance < 30 && percentageOfAttendance >= 60.0) {
                    grade = "C";
                } else {
                    grade = "D";
                }

                String details = String.format("EmpName: %s\nPercentage of Attendance: %.2f\nOverall Performance: %d\nGrade: %s",
                        empName, percentageOfAttendance, overallPerformance, grade);
                resultArea.setText(details);
            } else {
                resultArea.setText("Employee not found.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error fetching data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        empIdField.setText("");
        resultArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EmployeeGradingApp();
            }
        });
    }
}

