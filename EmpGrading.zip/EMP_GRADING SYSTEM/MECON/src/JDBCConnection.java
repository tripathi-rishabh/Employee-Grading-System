import java.sql.*;
import java.util.*;
public class JDBCConnection
{
    public static void main(String[] args) throws Exception
    {

        Scanner sc= new Scanner(System.in);
        System.out.println("Enter Employee ID to display details :");
        int EmpID=sc.nextInt();

        String sql = "Select EmpName, EmpAge, EmpDept from Employee where EmpID = "+EmpID;
        String url="jdbc:mySQL://localhost:3306/mecon";
        String username="Rishabh";
        String password="6163";

        java.sql.Connection con= DriverManager.getConnection(url, username, password);
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery(sql);
        rs.next();

        String EmpName=rs.getString(1);
        String EmpAge=rs.getString(2);
        String EmpDept= rs.getString(3);

        System.out.println("Employee Name is :" +EmpName);
        System.out.println("Employee Age is :" +EmpAge);
        System.out.println("Employee Dept is :" +EmpDept);
        con.close();
    }
}


