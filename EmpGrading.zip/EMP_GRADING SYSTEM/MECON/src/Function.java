import java.sql.*;
import java.util.*;

public class Function {
    private static String url    ="jdbc:mysql://localhost:3306/mecon";
    private static String usrname="Rishabh";
    private static String pass   ="6163";
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");}
        catch(ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
        try{
            System.out.println("Enter EmpID to find the performance:");
            String EmpID = sc.nextLine();
            java.sql.Connection con=DriverManager.getConnection(url,usrname,pass);
            String Query      = " Select EmpID,EmpName, Overall, Percentage from performance NATURAL JOIN attendance NATURAL JOIN employee where EmpID = ?";
            PreparedStatement preparedStatement = con.prepareStatement(Query);
            preparedStatement.setString(1, EmpID);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){

                String EmpName   = resultSet.getString("EmpName");
                double Percentage_of_attendance    = resultSet.getInt("Percentage");
                int Overall_Performance  = resultSet.getInt("Overall");


                if(Overall_Performance>=40 && Percentage_of_attendance>=90.0){

                    System.out.println("EmpName is->" +" "+EmpName);
                    System.out.println("Percentage of attendance is ->"+ " "+Percentage_of_attendance);
                    System.out.println("Overall performance is ->"+" "+Overall_Performance);

                    System.out.println("Grade -> A+");
                    System.out.println();
                }
                else if(Overall_Performance>=35 && Overall_Performance<=40 &&Percentage_of_attendance>=80.0){

                    System.out.println("EmpName is->" +" "+EmpName);
                    System.out.println("Percentage of attendance is ->"+" "+Percentage_of_attendance);
                    System.out.println("Overall performance is ->"+" "+Overall_Performance);

                    System.out.println("Grade -> A");
                    System.out.println();
                }

                else if(Overall_Performance>=30 && Overall_Performance<=35 &&Percentage_of_attendance>=70.0){

                    System.out.println("EmpName is->" +" "+EmpName);
                    System.out.println("Percentage of attendance is ->"+" "+Percentage_of_attendance);
                    System.out.println("Overall performance is ->"+" "+Overall_Performance);

                    System.out.println("Grade -> B");
                    System.out.println();
                }
                else if(Overall_Performance>=25 && Overall_Performance<=30 &&Percentage_of_attendance>=60.0){

                    System.out.println("EmpName is->" +" "+EmpName);
                    System.out.println("Percentage of attendance is ->"+" "+Percentage_of_attendance);
                    System.out.println("Overall performance is ->"+" "+Overall_Performance);

                    System.out.println("Grade -> C");
                    System.out.println();
                }
                else{

                    System.out.println("EmpName is->" +" "+EmpName);
                    System.out.println("Percentage of attendance is ->"+" "+Percentage_of_attendance);
                    System.out.println("Overall performance is ->"+" "+Overall_Performance);
                    System.out.println("Grade -> D");
                    System.out.println();
                }
            }

        }
        catch (SQLException se){
            System.out.println(se.getMessage());
        }
    }
}
